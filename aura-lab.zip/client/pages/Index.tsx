import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Trash2, Plus, Calendar } from "lucide-react";

interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: Date;
  updatedAt: Date;
}

export default function Index() {
  const [notes, setNotes] = useState<Note[]>([
    {
      id: "1",
      title: "Welcome to Notes",
      content: "Click on any note to edit it, or create a new one with the + button.",
      createdAt: new Date(Date.now() - 86400000),
      updatedAt: new Date(Date.now() - 86400000),
    },
    {
      id: "2",
      title: "Your Notes are Auto-Saved",
      content: "All changes to your notes are automatically saved in real-time.",
      createdAt: new Date(Date.now() - 3600000),
      updatedAt: new Date(Date.now() - 3600000),
    },
  ]);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editContent, setEditContent] = useState("");
  const [showNewNoteForm, setShowNewNoteForm] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newContent, setNewContent] = useState("");

  const createNote = () => {
    if (!newTitle.trim() && !newContent.trim()) return;

    const note: Note = {
      id: Date.now().toString(),
      title: newTitle || "Untitled Note",
      content: newContent,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    setNotes([note, ...notes]);
    setNewTitle("");
    setNewContent("");
    setShowNewNoteForm(false);
  };

  const startEditing = (note: Note) => {
    setEditingId(note.id);
    setEditTitle(note.title);
    setEditContent(note.content);
  };

  const saveEdit = () => {
    setNotes(
      notes.map((note) =>
        note.id === editingId
          ? {
              ...note,
              title: editTitle || "Untitled Note",
              content: editContent,
              updatedAt: new Date(),
            }
          : note
      )
    );
    setEditingId(null);
  };

  const deleteNote = (id: string) => {
    setNotes(notes.filter((note) => note.id !== id));
  };

  const formatDate = (date: Date) => {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return date.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      });
    } else if (date.toDateString() === yesterday.toDateString()) {
      return "Yesterday";
    } else {
      return date.toLocaleDateString([], {
        month: "short",
        day: "numeric",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="sticky top-0 z-10 border-b border-blue-100/50 bg-white/80 backdrop-blur-md">
        <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Notes</h1>
              <p className="mt-1 text-sm text-slate-600">
                {notes.length} {notes.length === 1 ? "note" : "notes"}
              </p>
            </div>
            <Button
              onClick={() => setShowNewNoteForm(true)}
              className="gap-2 bg-indigo-600 hover:bg-indigo-700"
              size="lg"
            >
              <Plus className="h-5 w-5" />
              New Note
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
        {/* New Note Form */}
        {showNewNoteForm && (
          <div className="mb-8 rounded-xl border border-indigo-200 bg-white p-6 shadow-lg">
            <h2 className="mb-4 text-xl font-semibold text-slate-900">
              Create a new note
            </h2>
            <div className="space-y-4">
              <Input
                placeholder="Note title..."
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="border-slate-200 text-base"
                autoFocus
              />
              <Textarea
                placeholder="What's on your mind?"
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                className="min-h-32 border-slate-200 text-base"
              />
              <div className="flex justify-end gap-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowNewNoteForm(false);
                    setNewTitle("");
                    setNewContent("");
                  }}
                >
                  Cancel
                </Button>
                <Button
                  onClick={createNote}
                  className="bg-indigo-600 hover:bg-indigo-700"
                >
                  Create Note
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Notes Grid */}
        {notes.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 py-16">
            <p className="text-lg font-medium text-slate-700">No notes yet</p>
            <p className="mt-2 text-sm text-slate-600">
              Create your first note to get started
            </p>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {notes.map((note) => (
              <div
                key={note.id}
                className="group relative rounded-xl border border-slate-200 bg-white shadow-sm transition-all duration-200 hover:shadow-md hover:border-indigo-200"
              >
                {editingId === note.id ? (
                  // Edit Mode
                  <div className="p-5">
                    <Input
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      className="mb-3 border-slate-200 text-sm font-semibold"
                      autoFocus
                    />
                    <Textarea
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      className="mb-4 min-h-24 border-slate-200 text-sm"
                    />
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setEditingId(null)}
                      >
                        Cancel
                      </Button>
                      <Button
                        size="sm"
                        className="bg-indigo-600 hover:bg-indigo-700"
                        onClick={saveEdit}
                      >
                        Save
                      </Button>
                    </div>
                  </div>
                ) : (
                  // View Mode
                  <>
                    <div
                      className="cursor-pointer p-5"
                      onClick={() => startEditing(note)}
                    >
                      <h3 className="mb-2 line-clamp-2 text-base font-semibold text-slate-900">
                        {note.title}
                      </h3>
                      <p className="line-clamp-4 text-sm leading-relaxed text-slate-600">
                        {note.content}
                      </p>
                    </div>
                    <div className="flex items-center justify-between border-t border-slate-100 px-5 py-3 text-xs text-slate-500">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3.5 w-3.5" />
                        {formatDate(new Date(note.updatedAt))}
                      </div>
                      <button
                        onClick={() => deleteNote(note.id)}
                        className="rounded p-1 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                        aria-label="Delete note"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
